import React, { useEffect, useState } from "react";
import { Card } from "../components/ui/Card";
import { Table } from "../components/ui/Table";
import { Button } from "../components/ui/Button";
import { LoadingSpinner } from "../components/ui/LoadingSpinner";

export default function HybridJobs() {
  const [rows, setRows] = useState<any[]>([]);
const [loading, setLoading] = useState(false);
const [inputUrl, setInputUrl] = useState("https://storage.googleapis.com/isn/test/input.mp4");
const [source, setSource] = useState("hi");
const [target, setTarget] = useState("en");

async function run() {
  setLoading(true);
  const { runHybrid } = await import("../lib/hybridApi");
  try {
    const res = await runHybrid(inputUrl, source, target);
    setRows((r)=>[res, ...r]);
  } finally { setLoading(false); }
}

return (
  <div className="p-4 space-y-4">
    <Card>
      <div className="flex gap-2">
        <input className="border p-2 flex-1" value={inputUrl} onChange={e=>setInputUrl(e.target.value)} placeholder="Input video URL" />
        <input className="border p-2 w-24" value={source} onChange={e=>setSource(e.target.value)} placeholder="src" />
        <input className="border p-2 w-24" value={target} onChange={e=>setTarget(e.target.value)} placeholder="tgt" />
        <Button onClick={run} disabled={loading}>{loading ? "Running..." : "Run Hybrid"}</Button>
      </div>
    </Card>
    <Card>
      <Table
        columns={[ "job_id", "status", "provider_used", "cost_cents" ]}
        data={rows}
      />
    </Card>
  </div>
);
}
