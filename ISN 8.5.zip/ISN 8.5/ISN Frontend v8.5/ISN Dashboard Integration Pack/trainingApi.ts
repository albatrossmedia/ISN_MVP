// src/lib/trainingApi.ts
import { apiFetch } from "./api";

export function startHybridTraining(model_id = "isn_hybrid_v1", datasets = ["IndicSpeech:2025.09", "CineLing:2025.10"]) {
  return apiFetch(`/training/hybrid/start`, {
    method: "POST",
    body: JSON.stringify({
      model_id, datasets,
      config: { epochs: 2, batch_size: 64 },
      use_vertex_ai: true
    })
  });
}

export function listTrainingJobs() {
  return apiFetch(`/training_jobs`, { method: "GET" });
}

export function listTrainingMetrics(training_job_id: number) {
  return apiFetch(`/training_metrics?training_job_id=${training_job_id}`, { method: "GET" });
}
