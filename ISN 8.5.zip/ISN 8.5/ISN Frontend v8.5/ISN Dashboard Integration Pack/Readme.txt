📦 ISN Dashboard Integration Pack

Map/Guide: ISN_Dashboard_Integration_Map_v8.6.md

API clients (put under project/src/lib/):

hybridApi.ts

trainingApi.ts

complianceApi.ts

billingApi.ts

metricsApi.ts

New pages (put under project/src/pages/):

HybridJobs.tsx

SQILive.tsx

ComplianceReports.tsx

TrainingJobs.tsx

BillingInvoices.tsx

Providers.tsx

There’s also a tiny note: _readme_note.txt

How this maps to your backend & Postman

Hybrid Orchestration → HybridJobs.tsx uses /hybrid/run, /hybrid/merge, /poc/*

SQI (Realtime) → SQILive.tsx subscribes to SSE at /sqi/stream?job_id=...

Compliance → ComplianceReports.tsx lists compliance_reports, compliance_flags

Training → TrainingJobs.tsx lists training_jobs, training_metrics; triggers /training/hybrid/start

Billing → BillingInvoices.tsx lists billing_invoices, billing_items

Provider Metrics → Providers.tsx shows provider_metrics (WER, Latency, SQI, cost/min)

Add these to your router (App.tsx)
<Route path="/hybrid" element={<HybridJobs />} />
<Route path="/sqi" element={<SQILive />} />
<Route path="/compliance" element={<ComplianceReports />} />
<Route path="/training" element={<TrainingJobs />} />
<Route path="/billing" element={<BillingInvoices />} />
<Route path="/providers" element={<Providers />} />

.env for the dashboard
VITE_API_BASE=https://api.indicsubtitlenet.com/v1
VITE_SOCKET_URL=wss://api.indicsubtitlenet.com/ws
VITE_GRAFANA_URL=https://grafana.indicsubtitlenet.com

Quick sanity checklist (all in sync)

Postman collection: v8.5-Hybrid-Full ✅

Backend routes implemented per your v8.6 Fix Map (especially /hybrid/*, /poc/*, /sqi/stream, /training/*, /billing_*, /provider_metrics, /compliance_*) ✅

DB is migrated to create_full_schema_v8.6.sql ✅

Dashboard now points to exact same endpoints and fields used by backend & Postman ✅