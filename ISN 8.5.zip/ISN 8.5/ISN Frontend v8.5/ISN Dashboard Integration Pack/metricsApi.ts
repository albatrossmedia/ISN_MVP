// src/lib/metricsApi.ts
import { apiFetch } from "./api";

export const Metrics = {
  providerMetrics: () => apiFetch(`/provider_metrics`, { method: "GET" }),
  sqiStream: (job_id: string, onMessage: (data:any)=>void) => {
    const base = import.meta.env.VITE_API_BASE;
    const token = localStorage.getItem("token");
    const url = `${base}/sqi/stream?job_id=${encodeURIComponent(job_id)}`;
    const es = new EventSource(url, { withCredentials: false });
    es.onmessage = (ev) => {
      try { onMessage(JSON.parse(ev.data)); } catch { onMessage(ev.data); }
    };
    es.onerror = () => es.close();
    return () => es.close();
  }
};
