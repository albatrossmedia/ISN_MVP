import React, { useEffect, useState } from "react";
import { Card } from "../components/ui/Card";
import { Table } from "../components/ui/Table";
import { Button } from "../components/ui/Button";
import { LoadingSpinner } from "../components/ui/LoadingSpinner";

export default function SQILive() {
  const [events, setEvents] = useState<any[]>([]);
const [jobId, setJobId] = useState("JOB-TEST-001");

useEffect(()=>{
  let off: any;
  (async () => {
    const {{ Metrics }} = await import("../lib/metricsApi");
    off = Metrics.sqiStream(jobId, (msg)=> setEvents(e=>[msg, ...e].slice(0,200)));
  })();
  return ()=> off && off();
}, [jobId]);

return (
  <div className="p-4 space-y-4">
    <Card>
      <div className="flex gap-2">
        <input className="border p-2" value={jobId} onChange={e=>setJobId(e.target.value)} />
      </div>
    </Card>
    <Card>
      <Table columns={[ "sqi_score", "emotion_alignment", "caption_density", "latency_s" ]} data={events} />
    </Card>
  </div>
);
}
