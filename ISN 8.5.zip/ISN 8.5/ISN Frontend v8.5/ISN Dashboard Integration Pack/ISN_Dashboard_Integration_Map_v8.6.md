# ISN MDMS Admin Dashboard — Integration Map (v8.6 Hybrid)

**Goal:** Bring the React admin dashboard in sync with ISN_Backend_v8.6 APIs and the Postman collection `ISN_Universal_API_Collection_v8.5-Hybrid-Full.json`.

## ✅ Current Pages Detected
- Dashboard.tsx
- Jobs.tsx
- Datasets.tsx
- Models.tsx
- Users.tsx
- AuditLogs.tsx
- SystemHealth.tsx
- DatasetPerformance.tsx
- ModelPerformance.tsx
- Auth: Login.tsx, SignUp.tsx, ForgotPassword.tsx

## 🧩 New Pages to Add (v8.6)
1. **HybridJobs.tsx** — monitor `/hybrid/run`, `/hybrid/merge`, `/poc/*` results
2. **SQILive.tsx** — live SQI stream view from `/sqi/stream?job_id=...`
3. **ComplianceReports.tsx** — list `compliance_reports`, `compliance_flags`
4. **TrainingJobs.tsx** — track `training_jobs`, `training_metrics`
5. **BillingInvoices.tsx** — show `billing_invoices`, `billing_items`
6. **Providers.tsx** — compare `provider_metrics` across STT vs Gemini

## 🌐 Environment (.env) — add these
```
VITE_API_BASE=https://api.indicsubtitlenet.com/v1
VITE_SOCKET_URL=wss://api.indicsubtitlenet.com/ws
VITE_GRAFANA_URL=https://grafana.indicsubtitlenet.com
```

## 🔗 API Client Modules (src/lib/*)
Add the following files:
- `hybridApi.ts` — Hybrid orchestration
- `trainingApi.ts` — Vertex AI training ops
- `complianceApi.ts` — Compliance data
- `billingApi.ts` — Invoices and usage
- `metricsApi.ts` — Provider metrics & SQI stream

> Keep existing `api.ts` as the base fetch wrapper with token injection.

## 🗺️ Backend ↔ Frontend Mapping (Key Endpoints)
| Backend Endpoint | Dashboard Module | UI Component |
|------------------|------------------|--------------|
| `POST /hybrid/run` | HybridJobs.tsx | Button “Run Hybrid” + Table row |
| `POST /hybrid/merge` | HybridJobs.tsx | Action “Merge Outputs” |
| `POST /poc/test-stt` | HybridJobs.tsx | Quick test card |
| `POST /poc/test-gemini` | HybridJobs.tsx | Quick test card |
| `POST /poc/compare` | Providers.tsx | Compare chart (WER/Latency/SQI) |
| `GET /sqi/stream` (SSE) | SQILive.tsx | Live graph (sparkline) |
| `GET /provider_metrics` | Providers.tsx | Table & chart |
| `GET /compliance_reports` | ComplianceReports.tsx | Table list |
| `GET /training_jobs` | TrainingJobs.tsx | Table + status pill |
| `GET /billing_invoices` | BillingInvoices.tsx | Table + download |

## 🧭 Router Additions (App.tsx)
Add these routes:
```tsx
<Route path="/hybrid" element={<HybridJobs />} />
<Route path="/sqi" element={<SQILive />} />
<Route path="/compliance" element={<ComplianceReports />} />
<Route path="/training" element={<TrainingJobs />} />
<Route path="/billing" element={<BillingInvoices />} />
<Route path="/providers" element={<Providers />} />
```

## 📈 Charts & Tables
- Use existing `ui/Table.tsx`, `ui/Card.tsx`, `ui/Tabs.tsx` for lists.
- For charts, minimal sparkline via `<canvas>` or a small chart lib if available.

## ✅ Postman Sync
All endpoints mirror the Postman collection groups:
- Hybrid Orchestration
- Observability & Metrics (Hybrid)
- Training & Feedback
- POC Validation

---

## 📦 Deliverables in this Pack
- `hybridApi.ts`, `trainingApi.ts`, `complianceApi.ts`, `billingApi.ts`, `metricsApi.ts` (ready-to-drop)
- Page scaffolds for: `HybridJobs.tsx`, `SQILive.tsx`, `ComplianceReports.tsx`, `TrainingJobs.tsx`, `BillingInvoices.tsx`, `Providers.tsx`

