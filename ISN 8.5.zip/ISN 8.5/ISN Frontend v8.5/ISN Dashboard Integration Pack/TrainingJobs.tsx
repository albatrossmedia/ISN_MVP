import React, { useEffect, useState } from "react";
import { Card } from "../components/ui/Card";
import { Table } from "../components/ui/Table";
import { Button } from "../components/ui/Button";
import { LoadingSpinner } from "../components/ui/LoadingSpinner";

export default function TrainingJobs() {
  const [rows, setRows] = useState<any[]>([]);
useEffect(()=>{ (async()=>{ const { listTrainingJobs } = await import("../lib/trainingApi"); const res = await listTrainingJobs(); setRows(res?.items || res || []); })(); },[]);
return (<div className="p-4"><Card><Table columns={["model_id","dataset_id","vertex_job_id","status","accuracy"]} data={rows} /></Card></div>);
}
