import React, { useEffect, useState } from "react";
import { Card } from "../components/ui/Card";
import { Table } from "../components/ui/Table";
import { Button } from "../components/ui/Button";
import { LoadingSpinner } from "../components/ui/LoadingSpinner";

export default function BillingInvoices() {
  const [rows, setRows] = useState<any[]>([]);
useEffect(()=>{ (async()=>{ const { Billing } = await import("../lib/billingApi"); const res = await Billing.listInvoices(); setRows(res?.items || res || []); })(); },[]);
return (<div className="p-4"><Card><Table columns={["invoice_id","tenant_id","period","total_amount_cents","payment_status"]} data={rows} /></Card></div>);
}
