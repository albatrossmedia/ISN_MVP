import React, { useEffect, useState } from "react";
import { Card } from "../components/ui/Card";
import { Table } from "../components/ui/Table";
import { Button } from "../components/ui/Button";
import { LoadingSpinner } from "../components/ui/LoadingSpinner";

export default function ComplianceReports() {
  const [rows, setRows] = useState<any[]>([]);
useEffect(()=>{ (async()=>{ const { Compliance } = await import("../lib/complianceApi"); const res = await Compliance.listReports(); setRows(res?.items || res || []); })(); },[]);
return (<div className="p-4"><Card><Table columns={["dataset_id","job_id","risk_level","score","reviewer"]} data={rows} /></Card></div>);
}
