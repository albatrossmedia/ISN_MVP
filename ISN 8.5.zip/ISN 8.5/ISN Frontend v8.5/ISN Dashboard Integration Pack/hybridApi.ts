// src/lib/hybridApi.ts
import { apiFetch } from "./api";

export function runHybrid(inputUrl: string, source_lang: string, target_lang: string) {
  return apiFetch(`/hybrid/run`, {
    method: "POST",
    body: JSON.stringify({
      input: { url: inputUrl },
      source_lang, target_lang,
      pipeline: ["stt", "gemini_translate", "srt_format"],
      options: { timestamps: true, tone: "cinematic" }
    })
  });
}

export function mergeHybrid(jobId: string) {
  return apiFetch(`/hybrid/merge`, {
    method: "POST",
    body: JSON.stringify({
      stt_output: `https://cdn.isn/jobs/${jobId}/stt.json`,
      gemini_output: `https://cdn.isn/jobs/${jobId}/gemini.json`,
      metadata: { job_id: jobId }
    })
  });
}

export const poc = {
  testSTT: (audio_url: string, lang = "hi-IN") => apiFetch(`/poc/test-stt`, {
    method: "POST", body: JSON.stringify({ audio_url, lang })
  }),
  testGemini: (video_url: string, target_lang = "en") => apiFetch(`/poc/test-gemini`, {
    method: "POST", body: JSON.stringify({ video_url, target_lang })
  }),
  compare: () => apiFetch(`/poc/compare`, {
    method: "POST", body: JSON.stringify({ providers: ["google_vertex_stt", "gemini_multimodal"], metrics: ["WER","Latency","SQI"] })
  })
};
