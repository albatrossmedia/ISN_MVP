import React, { useEffect, useState } from "react";
import { Card } from "../components/ui/Card";
import { Table } from "../components/ui/Table";
import { Button } from "../components/ui/Button";
import { LoadingSpinner } from "../components/ui/LoadingSpinner";

export default function Providers() {
  const [rows, setRows] = useState<any[]>([]);
useEffect(()=>{ (async()=>{ const { Metrics } = await import("../lib/metricsApi"); const res = await Metrics.providerMetrics(); setRows(res?.items || res || []); })(); },[]);
return (<div className="p-4"><Card><Table columns={["provider","lang","p50_ms","p95_ms","wer","bleu","success_rate","cost_per_min"]} data={rows} /></Card></div>);
}
