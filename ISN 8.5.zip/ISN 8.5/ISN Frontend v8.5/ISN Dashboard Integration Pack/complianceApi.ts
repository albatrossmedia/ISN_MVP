// src/lib/complianceApi.ts
import { apiFetch } from "./api";

export const Compliance = {
  listReports: () => apiFetch(`/compliance_reports`, { method: "GET" }),
  listFlags: (dataset_id?: string) => apiFetch(`/compliance_flags${dataset_id ? `?dataset_id=${dataset_id}` : ""}`),
};
