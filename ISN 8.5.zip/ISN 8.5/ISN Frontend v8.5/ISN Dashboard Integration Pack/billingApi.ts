// src/lib/billingApi.ts
import { apiFetch } from "./api";

export const Billing = {
  listInvoices: (tenant_id?: string) => apiFetch(`/billing_invoices${tenant_id ? `?tenant_id=${tenant_id}` : ""}`),
  listItems: (invoice_id: string) => apiFetch(`/billing_items?invoice_id=${invoice_id}`),
  usage: (tenant_id: string, period?: string) => apiFetch(`/billing_usage?tenant_id=${tenant_id}${period ? `&period=${period}` : ""}`)
};
