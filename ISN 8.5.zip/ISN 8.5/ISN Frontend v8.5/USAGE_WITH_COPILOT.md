# 🤖 Using GitHub Copilot with ISN Dashboard v8.6

> Quickly refactor and align the React MDMS Admin Dashboard with  
> **ISN_Backend_v8.6**, **Postman v8.5-Hybrid-Full**, and **create_full_schema_v8.6.sql**

---

## 🧠 1️⃣ Open Your Project
- Launch **Visual Studio Code**.  
- Open your **ISN Dashboard** project folder.

---

## 💬 2️⃣ Open Copilot Chat or README
You can give Copilot the full v8.6 refactor prompt in either place:

### ✅ Option A – Inside README
1. Open `README.md` at the root of the project.  
2. Paste the entire Copilot prompt titled  
   **“Refactor and Enhance ISN MDMS Admin Dashboard (React) for v8.6-Hybrid Integration.”**

### ✅ Option B – Copilot Chat
1. Open **Copilot Chat** (`Ctrl + Shift + I` or `Cmd + Shift + I`).  
2. Paste the same prompt.  
3. Press **Enter**.

---

## 🧩 3️⃣ Ask Copilot
In chat, type:

> “Apply this refactor plan to improve code quality and API integration for ISN v8.6.”

Copilot will:
- Analyze your existing `/src` files.  
- Generate or update:  
  - `src/lib/hybridApi.ts`, `trainingApi.ts`, `billingApi.ts`, `metricsApi.ts`, `complianceApi.ts`  
  - `src/pages/HybridJobs.tsx`, `SQILive.tsx`, `TrainingJobs.tsx`, `BillingInvoices.tsx`, `Providers.tsx`, `ComplianceReports.tsx`  
  - Routing in `App.tsx`.

---

## 🧾 4️⃣ Review and Accept
- Copilot shows diffs in VS Code.  
- Accept or edit each suggestion.  
- Confirm new environment variables exist in `.env`:

```bash
VITE_API_BASE=https://api.indicsubtitlenet.com/v1
VITE_SOCKET_URL=wss://api.indicsubtitlenet.com/ws
VITE_GRAFANA_URL=https://grafana.indicsubtitlenet.com
```

---

## 🧠 5️⃣ Run and Verify
```bash
npm install
npm run dev
```

Test these pages:
| URL | Feature |
|-----|----------|
| `/hybrid` | STT + Gemini orchestration |
| `/sqi` | Live Subtitle Quality Index |
| `/training` | Vertex AI training jobs |
| `/billing` | Invoices + usage |
| `/providers` | Provider metrics |
| `/compliance` | Risk and flag reports |

---

## 🧭 6️⃣ Iterate
If Copilot stops early, ask again:

> “Continue applying the ISN v8.6 dashboard integration plan.”

---

## 🧩 7️⃣ Commit and Push
```bash
git add .
git commit -m "Refactored dashboard for ISN v8.6 Hybrid Integration"
git push origin main
```

---

### 💡 Tips
- Enable Copilot Chat Extension.  
- Set context scope → **Full Workspace**.  
- Keep both `README_Dashboard_v8.6.md` and this guide in your repo for future developers.

---

> _“Let Copilot handle the refactor — you focus on design and insight.”_
