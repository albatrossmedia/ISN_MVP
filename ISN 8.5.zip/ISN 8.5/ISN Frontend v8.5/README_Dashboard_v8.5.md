# 🧭 IndicSubtitleNet — MDMS Admin Dashboard (v8.5-Hybrid)

> React + TailwindCSS + Vite + TypeScript  
> Connected to **ISN_Backend_v8.5-Final** (Node.js + MySQL + Redis + Vertex AI + Grafana)

---

## 🚀 Overview

The **ISN MDMS Admin Dashboard v8.5** is a unified management interface for:
- Monitoring transcription & translation jobs (STT + Gemini)
- Managing datasets, models, and hybrid training pipelines
- Tracking Subtitle Quality Index (SQI) in real time
- Overseeing compliance, billing, and provider performance

This version fully integrates with the **ISN Hybrid Architecture**:
- Speech-to-Text (Chirp / Vertex AI)
- Gemini Multimodal API (Text/Video)
- Vertex AI Training Jobs
- Grafana Metrics & OpenTelemetry Observability

---

## 🏗️ Folder Structure

```
src/
 ├── pages/
 │   ├── Dashboard.tsx
 │   ├── Jobs.tsx
 │   ├── Datasets.tsx
 │   ├── Models.tsx
 │   ├── HybridJobs.tsx         # NEW — hybrid STT + Gemini orchestration
 │   ├── SQILive.tsx            # NEW — live SQI stream dashboard
 │   ├── ComplianceReports.tsx  # NEW — compliance risk reports
 │   ├── TrainingJobs.tsx       # NEW — Vertex AI training tracker
 │   ├── BillingInvoices.tsx    # NEW — invoices & usage
 │   └── Providers.tsx          # NEW — STT vs Gemini performance comparison
 │
 ├── lib/
 │   ├── api.ts                 # Base API fetch client
 │   ├── hybridApi.ts           # /hybrid, /poc endpoints
 │   ├── trainingApi.ts         # /training, /training_metrics
 │   ├── complianceApi.ts       # /compliance_reports, /flags
 │   ├── billingApi.ts          # /billing_invoices, /usage
 │   └── metricsApi.ts          # /provider_metrics, /sqi/stream
 │
 ├── components/
 │   ├── ui/ (shared components: Table, Card, Modal, Button)
 │   ├── layout/ (Sidebar, TopBar, MainLayout)
 │   └── charts/ (Provider comparison, SQI graphs)
 │
 ├── hooks/
 │   ├── useAuth.ts
 │   ├── useSQIStream.ts        # NEW — real-time SQI listener
 │   └── usePagination.ts
 │
 ├── layout/
 ├── styles/
 └── main.tsx
```

---

## 🌐 Environment Variables

Create `.env` in project root:

```bash
VITE_API_BASE=https://api.indicsubtitlenet.com/v1
VITE_SOCKET_URL=wss://api.indicsubtitlenet.com/ws
VITE_GRAFANA_URL=https://grafana.indicsubtitlenet.com
```

---

## 🔗 Backend & API Sync

| Layer | Connected Module | Description |
|--------|------------------|--------------|
| **Backend** | ISN_Backend_v8.5 | Node.js + MySQL + Redis + Vertex AI |
| **API Collection** | ISN_Universal_API_Collection_v8.5-Hybrid-Full.json | All REST endpoints |
| **Docs** | ISN_Universal_API_Documentation_v8.5-Hybrid-Full.md | Reference for request/response schema |
| **SQL Schema** | create_full_schema_v8.5.sql | Database structure |
| **Monitoring** | Grafana + OpenTelemetry | SQI & provider performance charts |

---

## ⚙️ Integration Summary

### 🧩 Hybrid Jobs
- **Endpoints:** `/hybrid/run`, `/hybrid/merge`, `/poc/test-stt`, `/poc/test-gemini`, `/poc/compare`
- **Page:** `HybridJobs.tsx`
- **Purpose:** Trigger & monitor STT + Gemini combined workflows.

### 📊 SQI Live
- **Endpoints:** `/sqi/stream`
- **Page:** `SQILive.tsx`
- **Purpose:** Real-time subtitle quality stream via SSE.

### 🧠 Training Jobs
- **Endpoints:** `/training/hybrid/start`, `/training_jobs`, `/training_metrics`
- **Page:** `TrainingJobs.tsx`
- **Purpose:** Vertex AI hybrid model fine-tuning.

### 🧾 Billing & Usage
- **Endpoints:** `/billing_invoices`, `/billing_items`, `/billing_usage`
- **Page:** `BillingInvoices.tsx`
- **Purpose:** Manage tenant invoices and per-minute usage.

### 🛡️ Compliance
- **Endpoints:** `/compliance_reports`, `/compliance_flags`
- **Page:** `ComplianceReports.tsx`
- **Purpose:** Risk and dataset compliance audit.

### 📈 Providers & Metrics
- **Endpoints:** `/provider_metrics`
- **Page:** `Providers.tsx`
- **Purpose:** Compare WER, Latency, SQI between STT and Gemini.

---

## 🖥️ UI/UX Guidelines

- Use TailwindCSS for consistent spacing and typography.
- Every page must display:
  - `LoadingSpinner` while fetching.
  - Empty state with placeholder text.
  - Error toast on failure (`react-hot-toast`).
- Reuse `<Card>` and `<Table>` for all list views.
- Charts (where applicable) via `components/charts/*` or Grafana iFrame.

---

## 🔐 Authentication

- Token stored in `localStorage` as `token`.
- All API requests add:
  ```ts
  headers: { Authorization: "Bearer <token>" }
  ```
- `useAuth()` hook handles login persistence and logout redirection.

---

## 📡 Real-Time Streaming

The dashboard connects to backend event streams for:
- SQI live updates via `/sqi/stream`
- Job progress via WebSocket (`VITE_SOCKET_URL`)

---

## 🧰 Developer Setup

### Install dependencies
```bash
npm install
```

### Run locally
```bash
npm run dev
```

### Build for production
```bash
npm run build
npm run preview
```

---

## 🧹 Quality & Code Style
- ESLint + Prettier enforced.
- TypeScript strict mode on.
- All components must have prop types.
- Use `async/await` and centralized error handling (`api.ts`).

---

## 🔍 Testing
1. Verify API endpoints with Postman Collection `ISN_Universal_API_Collection_v8.5-Hybrid-Full.json`.
2. Test dashboard pages for data rendering and state updates.
3. Validate WebSocket/SQI stream stability.
4. Confirm all tables, filters, and pagination load correctly.

---

## 📈 Observability

| Tool | Purpose |
|------|----------|
| **Grafana** | Real-time SQI, Provider, and Cost metrics |
| **Prometheus** | Backend performance stats |
| **OpenTelemetry** | Distributed tracing |
| **Cloud Logging** | GCP logs for Gemini + STT |

---

## 📦 Deployment
1. Build static assets → `npm run build`
2. Deploy `/dist` folder to:
   - Firebase Hosting / Cloud Run / Netlify / Vercel
3. Configure `VITE_API_BASE` and `VITE_GRAFANA_URL` per environment.

---

## 🧾 Version Info

| Component | Version |
|------------|----------|
| **Dashboard** | v8.5-Hybrid |
| **Backend** | ISN_Backend_v8.6-Final |
| **Database** | create_full_schema_v8.5.sql |
| **APIs** | v8.5-Hybrid-Full |
| **Docs** | v8.5-Hybrid-Full |
| **Observability** | Grafana + OTEL |

---

## 👥 Maintainers
**Albatross Media / IndicSubtitleNet Engineering**  
📍 Mumbai, India  
📧 engineering@indicsubtitlenet.com

---

> _“Data speaks through subtitles — ISN makes every language heard.”_
