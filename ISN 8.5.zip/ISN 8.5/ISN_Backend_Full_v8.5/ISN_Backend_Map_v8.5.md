# IndicSubtitleNet — Backend Fix Map (v8.5 Upgrade Plan)

**Generated on:** 2025-10-28 12:47:03 UTC  
**Based on:** ISN Project Root Architecture + ISN_Backend_Full_v8.5 Structure  
**Objective:** Align backend codebase with full Hybrid (Gemini + STT) architecture for production readiness.

---

## 🧩 Phase 1 — Core Configuration Layer

**Goal:** Establish a complete configuration system to support database, Redis, and Vertex AI integrations.

| File | Purpose | Status | Action |
|------|----------|---------|---------|
| `src/config/env.config.js` | Centralized environment loader for Node.js | ❌ Missing | Create file; load `.env` variables, validate required keys |
| `src/config/db.config.js` | MySQL/Prisma database connection handler | ❌ Missing | Implement using Sequelize or Prisma |
| `src/config/redis.config.js` | Redis client + BullMQ connection | ❌ Missing | Add Redis client setup with retry strategy |
| `src/config/cloud.config.js` | Google Cloud Storage + Vertex AI credentials | ❌ Missing | Use `@google-cloud/storage` and `@google-cloud/aiplatform` |
| `src/config/logger.config.js` | Global Winston logger setup | ❌ Missing | Configure transports (console + file + error.log) |

---

## 🧠 Phase 2 — Routing & Controllers

**Goal:** Implement complete REST routing for all modules, including the new Hybrid system.

| Route File | Controller | Description | Status |
|-------------|-------------|--------------|---------|
| `src/routes/auth.routes.js` | `auth.controller.js` | Authentication + token validation | ✅ Exists |
| `src/routes/jobs.routes.js` | `jobs.controller.js` | Job creation + progress tracking | ✅ Exists |
| `src/routes/models.routes.js` | `models.controller.js` | Model registry + active model info | ❌ Missing |
| `src/routes/datasets.routes.js` | `datasets.controller.js` | Dataset registration, lineage tracking | ❌ Missing |
| `src/routes/feedback.routes.js` | `feedback.controller.js` | Reviewer feedback + edit submission | ❌ Missing |
| `src/routes/billing.routes.js` | `billing.controller.js` | Invoice, payment, and usage logs | ❌ Missing |
| `src/routes/hybrid.routes.js` | `hybrid.controller.js` | Gemini + STT orchestration API | ❌ Missing |
| `src/routes/compliance.routes.js` | `compliance.controller.js` | License and content compliance audits | ❌ Missing |

---

## ⚙️ Phase 3 — Services Layer

**Goal:** Add backend logic for Gemini integration, hybrid orchestration, and pipeline services.

| Service | Description | Action |
|----------|--------------|--------|
| `src/services/geminiService.js` | Wrapper for Vertex AI Gemini 1.5-pro API (text/audio/video) | Implement REST + SDK integration |
| `src/services/hybridService.js` | Controls STT → Gemini → Output orchestration | Add function `runHybridWorkflow(jobId, config)` |
| `src/services/orchestratorService.js` | Manages model queueing and output merging | Extend for hybrid logic |
| `src/services/feedbackService.js` | Handles reviewer edits + feedback loops | Create new service |
| `src/services/billingService.js` | Tracks per-job billing & token usage | Implement cost computation per provider |

---

## 🔄 Phase 4 — Workers (BullMQ Layer)

**Goal:** Implement async job handling for long-running operations.

| Worker | Purpose | Action |
|---------|----------|--------|
| `src/jobs/hybrid.worker.js` | Executes `/hybrid/run` and `/hybrid/merge` background jobs | Create worker; use `hybridService.runHybridWorkflow()` |
| `src/jobs/training.worker.js` | Vertex AI model training handler | Create worker; call `/training/hybrid/start` |
| `src/jobs/compliance.worker.js` | Scans completed jobs for legal compliance | Create worker; invoke `complianceService.scanJob()` |
| `src/jobs/bulk.worker.js` | Parallel subtitle generation worker | Update logic to include Gemini task type |

---

## 🧱 Phase 5 — Middleware

**Goal:** Reinforce API reliability and access control.

| Middleware | Description | Action |
|-------------|--------------|--------|
| `src/middleware/auth.middleware.js` | Validates JWT tokens | Add `verifyToken(req,res,next)` |
| `src/middleware/validate.middleware.js` | Schema validation (Joi/Zod) | Add middleware per route type |
| `src/middleware/rateLimit.middleware.js` | Limits per-tenant request rate | Add Redis-based limiter |
| `src/middleware/error.middleware.js` | Central error handler | ✅ Exists — extend for hybrid job logs |

---

## 🧮 Phase 6 — ORM Models (MySQL)

**Goal:** Implement database models for all operational entities.

| Model | Fields (Key) | Status | Action |
|--------|---------------|---------|---------|
| `Tenant.js` | tenant_id, name, api_key, plan | ❌ Missing | Create Sequelize model |
| `Job.js` | job_id, tenant_id, status, provider, metrics | ✅ Exists |
| `Dataset.js` | dataset_id, type, source_uri, version | ❌ Missing |
| `Feedback.js` | feedback_id, job_id, reviewer, delta_json | ❌ Missing |
| `Billing.js` | invoice_id, tenant_id, job_id, usage_cost | ❌ Missing |
| `ProviderMetrics.js` | provider, latency, accuracy, cost | ❌ Missing |

---

## 🧠 Phase 7 — Utils

**Goal:** Add shared utility helpers.

| File | Description |
|------|--------------|
| `src/utils/logger.js` | Custom wrapper around Winston logger |
| `src/utils/manifestBuilder.js` | Generates output manifest for jobs |
| `src/utils/metrics.js` | Pushes SQI metrics to Prometheus |
| `src/utils/idempotency.js` | Prevents duplicate job execution |
| `src/utils/response.js` | Unified success/error response format |

---

## ☁️ Phase 8 — Infra & Deployment

**Goal:** Containerize and prepare for Vertex AI & GCP deployment.

| File/Folder | Description |
|--------------|--------------|
| `/infra/docker/Dockerfile` | Node.js app Docker config |
| `/infra/docker/docker-compose.yml` | Compose for app + Redis + MySQL |
| `/infra/k8s/deployment.yaml` | GKE deployment manifest |
| `/infra/k8s/service.yaml` | GKE service spec |
| `/infra/pubsub/subscription.yaml` | Pub/Sub connector for Vertex AI events |

---

## 📊 Phase 9 — Observability

**Goal:** Integrate OpenTelemetry and SQI metrics.

| Component | Description |
|------------|-------------|
| `src/observability/otel.js` | OpenTelemetry setup for tracing hybrid jobs |
| `src/observability/grafana.json` | Dashboard template |
| `src/observability/exporters.js` | Send traces to Grafana/Datadog |

---

## 🧩 Phase 10 — Testing & Validation

| Task | Description |
|-------|--------------|
| Postman | Use `ISN_Universal_API_Collection_v8.5-Hybrid-Full.json` |
| Environment | Import `ISN_Hybrid_Env_v1.json` |
| Verify | Run `/poc/test-stt`, `/poc/test-gemini`, `/poc/compare` |
| Logging | Check Grafana dashboards for SQI streams |
| Dataset Sync | Verify `/training/feedback/apply` updates datasets |

---

### ✅ Final Deliverable Targets

| Component | Deliverable |
|------------|-------------|
| Backend Code | `/backend/src/` complete hybrid modules |
| Postman API | ISN_Universal_API_Collection_v8.5-Hybrid-Full.json (already complete) |
| Environment | ISN_Universal_Environment_v8.5-Hybrid-Full.json (done) |
| Docs | ISN_Universal_API_Documentation_v8.5-Hybrid-Full.md |
| Infra | Docker + K8s manifests (pending) |
| Target Release | **ISN_Backend_v8.6-Final.zip** |

---

**Maintained by:**  
🧠 *Albatross Media — IndicSubtitleNet Core Engineering Team*  
📍 Mumbai, India  
