# IndicSubtitleNet — Smart Scaffold (v1.1)

**Goal:** a README-first scaffold that lets Copilot/Cursor generate production code in the right places.

Generated: 2025-10-17T07:33:32.650351Z

---

## Domains & Environments

### Public
- **Portal (future):** `https://www.indicsubtitlenet.com` — docs/marketing.
- **Client API Gateway:** `https://client.indicsubtitlenet.com` — partner-facing, limited endpoints.
- **Status Page (optional):** `https://status.indicsubtitlenet.com`

### Private / Internal
- **Core API (internal/developer):** `https://api.indicsubtitlenet.com` — full v8.3 endpoints.
- **Datasets:** `https://datasets.indicsubtitlenet.com` — catalog, signed URLs only.
- **Models (MDMS):** `https://models.indicsubtitlenet.com` — registry & metadata.
- **Admin Panel:** `https://panel.indicsubtitlenet.com` — ops/QA/billing/compliance.
- **Monitoring:** `https://monitor.indicsubtitlenet.com` — Grafana/Prometheus/Alertmanager.

> DNS is your choice; this mapping keeps **public** vs **internal** clear.

---

## API Endpoint Matrix (high-level)

**Client Edition (public):**
- `POST /auth/token`
- `POST /models/run`
- `GET  /jobs/status`
- `POST /feedback/submit`
- `GET  /billing/usage`
- Webhooks: `POST https://<client-url>/webhooks/isn/job` (delivered from us)

**Developer/Internal (private):**
- `/scheduler/route`, `/jobs/segments`, `/jobs/segments/merge`
- `/mdms/datasets/*`, `/models/*`
- `/observability/*`, `/qos/*`, `/security/*`
- `/compliance/*`

Detailed endpoint list in **docs/ENDPOINTS_MATRIX.md**.

---

## Tech Stack

- **Runtime:** Node.js 20 LTS
- **API:** Express, Helmet, CORS, AJV
- **Queues:** BullMQ on Redis 6+
- **DB:** MySQL 8 (mysql2/promise)
- **Storage:** S3/GCS-compatible (AWS S3, Google Cloud Storage, Wasabi)
- **Realtime:** Socket.IO (admin monitoring)
- **Providers:** OpenAI Whisper, Google Cloud Speech/Translate/Vertex AI
- **Transcode:** ffmpeg (via `fluent-ffmpeg`, `ffmpeg-static`)
- **Observability:** prom-client, Grafana, Prometheus, OTEL (collector)
- **Notifications:** Nodemailer (Email), Twilio or MSG91 (SMS)
- **Container/Orchestration:** Docker, Kubernetes (HPA), Nginx ingress
- **CI/CD:** GitHub Actions (sample in docs), image registry of your choice

---

## Install (Local Dev)

```bash
cd backend
npm install
cp .env.example .env
# Fill MySQL/Redis/Provider creds
docker compose -f ../infra/docker/docker-compose.yml up -d
npm run dev
```

## Hostinger (Testing Environment)

Your server:
- **8 vCPU, 32 GB RAM, 400 GB NVMe, 32 TB bandwidth**

Recommended:
- Docker & Docker Compose
- Nginx reverse proxy (TLS), Node 20, MySQL 8, Redis 7
- ffmpeg installed on host (or use container with `ffmpeg-static`)

See **docs/DEPLOYMENT_HOSTINGER.md**.

---

## Cloud Providers (Object Storage & AI)

- **AWS S3 / Wasabi:** media & outputs. Use presigned URLs; lifecycle to auto-delete raw videos.
- **Google Cloud:** Speech-to-Text/Translate (Vertex), Cloud Storage alternative.
- **OpenAI:** Whisper API for compare/fallback.

See **docs/CLOUD_PROVIDERS.md** for configuration templates and IAM scopes.

---

## Repository Map

- `backend/` — API gateway, services, workers, sockets, middleware
- `models/` — model handlers/configs (keep big files in artifact store)
- `datasets/` — manifests & samples (real corpora in object storage)
- `infra/` — Docker & K8s manifests, ingress, monitoring
- `sql/` — database DDL & migrations
- `docs/` — architecture, endpoints, deployment runbooks
- `monitoring/` — Grafana dashboards, Prometheus config, OTEL collector

This scaffold is **documentation-first**. Copilot/Cursor read these READMEs to generate correct code structure.
